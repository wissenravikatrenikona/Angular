import { Component, Input, OnInit } from '@angular/core';
import { HeaderService } from 'src/app/services/header.service';
import { UserProfileService } from 'src/app/services/user-profile.service';
import { DomSanitizer } from '@angular/platform-browser';

import { Router } from '@angular/router';

@Component({
  selector: 'app-header-content',
  templateUrl: './header-content.component.html',
  styleUrls: ['./header-content.component.sass']
})
export class HeaderContentComponent implements OnInit {

  emptyResponse: boolean = false;
  image: any;
  imageSrc: any;
  userProfile: UserProfile = new UserProfile;
  @Input() env: string = 'Training';
  isProfileVisible: boolean = false; 

  constructor(private router: Router,private userProfileService: UserProfileService,private sanitizer: DomSanitizer) { 
  }

  ngOnInit(): void {
  }

  getUserImage(){
    return this.userProfileService.getUserImg().subscribe(response => {
      this.image = response;
      let objectURL = 'data:image/jpeg;base64,' + this.image.data;

      this.imageSrc = this.sanitizer.bypassSecurityTrustUrl(objectURL);

      // 
      // this.imageSrc = 'data:image/jpeg;base64,' + this.image.data;
    });
  }


  showProfile(){
    this.getUserImage();
    if(!this.isProfileVisible){
    this.userProfileService.getUserProfile().subscribe((res:any) => {
      let tmp: any = [];
     
      if(res.data == undefined ){
        this.emptyResponse = true;
      }
      else{
        this.userProfile.emailId = res.data.emailId;
        this.userProfile.lob = res.data.lob;
        this.userProfile.title = res.data.title;
        this.userProfile.userName = res.data.userName;
        this.isProfileVisible = !this.isProfileVisible;
      }

      
    },
    error => {
      //console.log(error);
      this.emptyResponse = true;
    });
  }
  else{
  this.isProfileVisible = !this.isProfileVisible;
  }
  }

  navigateToSettings(){
    this.isProfileVisible = false;
    this.router.navigate(['/settings']);

  }
}
export class UserProfile {
  userName!: String;
  emailId!: String;
  title!: String;
  lob!: String;
}
