import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AppTestingModule } from 'src/app/app-testing/app-testing.module';
import { SideNavComponent } from '../side-nav/side-nav.component';
import { HeaderContentComponent } from './header-content/header-content.component';

import { HeaderComponent } from './header.component';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AppTestingModule],
      declarations: [ HeaderComponent, SideNavComponent, HeaderContentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
