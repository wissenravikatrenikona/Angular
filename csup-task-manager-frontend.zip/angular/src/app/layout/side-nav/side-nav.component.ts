import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from "@angular/platform-browser";

const iconsList = ['initial_costing', 'program', 'project'];
@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.sass']
})
export class SideNavComponent implements OnInit {

  @Input() isExpanded: boolean = false;  
  @Input() env: string = 'Training';
  @Output() toggleMenu = new EventEmitter();
  constructor(private matIconRegistry: MatIconRegistry, 
    private domSanitizer: DomSanitizer){
      iconsList.forEach((key) => {
        this.matIconRegistry.addSvgIcon(
          key,
          this.domSanitizer.bypassSecurityTrustResourceUrl(`assets/images/${key}.svg`)
        );
      });
  }

  public routeLinks = [
    { link: "home", name: "Dashboard", icon: "dashboard" },
    { link: "search", name: "Search", icon: "search" },
    { link: "initialcosting", name: "Initial costing", icon: "initial_costing", custom: true },
    { link: "transaction", name: "Transaction", icon: "swap_horiz" },
    { link: "program", name: "Program", icon: "program", custom: true},
    { link: "project", name: "Project", icon: "project", custom: true }
  ];
  
  ngOnInit(): void {
  }

}
