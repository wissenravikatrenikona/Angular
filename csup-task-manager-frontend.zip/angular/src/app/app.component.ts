import { Component } from '@angular/core';
import { ConstantsService } from './config/constants.service';
import { ConfigLoaderService } from './services/config-loader.service';
import { HeaderService } from './services/header.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.sass']
})
export class AppComponent {
  title = 'angular';
  
  constructor(private configService: ConfigLoaderService, private constantsService: ConstantsService, private headerService: HeaderService){
    constantsService.API_ENDPOINT = configService.apiEndpoint;
    headerService.environment = configService.environment;
  }
}
