import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SettingsComponent } from './settings/settings.component';
import { ProgramComponent } from './program/program.component';
import { ProjectComponent } from './project/project.component';
import { TaskManagerHomeComponent } from './task-manager-home/task-manager-home.component';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: TaskManagerHomeComponent },
  { path: 'settings', component: SettingsComponent },
  { path: 'program', component: ProgramComponent},
  { path: 'project', component: ProjectComponent}
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}