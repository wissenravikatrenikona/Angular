import { Component, ElementRef, OnDestroy, AfterViewInit, Input } from '@angular/core';
import { create, createOptions, RichEdit, Interval, RichEditUnit, DocumentFormat } from 'devexpress-richedit';

import {formatDate} from '@angular/common';

@Component({
  selector: 'app-richedit',
  template: '<div></div>',
  styleUrls: ['./richedit.component.sass']
})
export class RicheditComponent implements AfterViewInit, OnDestroy {
  private rich: RichEdit | undefined;
  @Input() public templateType: string = '';
  @Input() public templateData: any;
  private templateDocument: string = '';

  constructor(private element: ElementRef){};


  ngAfterViewInit(): void {
    // the createOptions() method creates an object that contains RichEdit options initialized with default values
    const options = createOptions();

    // events
    options.events.activeSubDocumentChanged = () => { };
    options.events.autoCorrect = () => { };
    options.events.calculateDocumentVariable = () => { };
    options.events.characterPropertiesChanged = () => { };
    options.events.contentInserted = () => { };
    options.events.contentRemoved = () => { };
    options.events.documentChanged = () => { };
    options.events.documentFormatted = () => { };
    options.ribbon.getTab(2)?.removeItem(235);
    options.ribbon.getTab(2)?.removeItem(236);
    options.ribbon.getTab(2)?.removeItem(368);
    options.ribbon.removeTab(0);
    options.ribbon.removeTab(5);
    options.events.documentLoaded = (s, e) => {
      // INVOICE DATE
      s.document.insertText(s.document.getText().indexOf("Invoice Date:") + 13, formatDate(this.templateData.value.invoiceDate, 'dd-MM-yyyy', 'en-US'));
      s.document.insertText(s.document.getText().indexOf("Invoice No.") + 11, ""+this.templateData.value.invoiceId)
      s.document.insertText(s.document.getText().indexOf("Our Reference:") + 14, this.templateData.value.ourReference);
      s.document.insertText(s.document.getText().indexOf("Premium due as of ") + 18, formatDate(this.templateData.value.dueDate, 'dd-MM-yyyy', 'en-US'));
      s.document.insertText(s.document.getText().indexOf("Policy no.") + 10, this.templateData.value.ourReference);
      s.document.insertText(s.document.getText().indexOf("e-mail dated ") + 13, formatDate(this.templateData.value.receiptDate, 'dd-MM-yyyy', 'en-US'));
      s.document.insertText(s.document.getText().indexOf("calculated as follows:") + 24, this.templateData.value.currency + " " + this.templateData.value.amount);
      s.document.insertText(s.document.getText().indexOf("remit the total amount of ") + 26, this.templateData.value.currency + " " + this.templateData.value.amount);
      s.document.insertText(s.document.getText().indexOf("quote on this reference ") + 24, this.templateData.value.ourReference);
      s.rangePermissionOptions.showBrackets = false;
      s.rangePermissionOptions.highlightRanges = false;
    };
    options.events.gotFocus = () => { };
    options.events.hyperlinkClick = () => { };
    options.events.keyDown = () => { };
    options.events.keyUp = () => { };
    options.events.paragraphPropertiesChanged = () => { };
    options.events.lostFocus = () => { };
    options.events.pointerDown = () => { };
    options.events.pointerUp = () => { };
    options.events.saving = () => { };
    options.events.saved = () => { };
    options.events.selectionChanged = () => { };    

    options.unit = RichEditUnit.Inch;

    options.autoCorrect = {
        correctTwoInitialCapitals: true,
        detectUrls: true,
        enableAutomaticNumbering: true,
        replaceTextAsYouType: true,
        caseSensitiveReplacement: false,
        replaceInfoCollection: [
            { replace: "wnwd", with: "well-nourished, well-developed" },
            { replace: "(c)", with: "©" }
        ],
    };
    // capitalize the first letter at the beginning of a new sentence/line
    options.events.autoCorrect = function (s, e) {
        if (e.text.length == 1 && /\w/.test(e.text)) {
            var prevText = s.document.getText(new Interval(e.interval.start - 2, 2));
            if (prevText.length == 0 || /^(\. |\? |\! )$/.test(prevText) || prevText.charCodeAt(1) == 13) {
                var newText = e.text.toUpperCase();
                if (newText != e.text) {
                    s.beginUpdate();
                    s.history.beginTransaction();
                    s.document.deleteText(e.interval);
                    s.document.insertText(e.interval.start, newText);
                    s.history.endTransaction();
                    s.endUpdate();
                    e.handled = true;
                }
            }
        }
    };  

    options.exportUrl = 'https://siteurl.com/api/';

    options.readOnly = false;
    options.width = '100%';
    options.height = '100%';
    this.rich = create(this.element.nativeElement.firstElementChild, options);
    switch (this.templateType) {
      case 'North American Capacity Insurance Company':
        //this.templateDocument = InvoiceTemplates.Carrier_SRNACIC_InvoiceTemplate;
        this.templateDocument = '';
    }
     this.rich.openDocument(this.templateDocument, "DocumentName", DocumentFormat.Rtf);
  }

  ngOnDestroy() {
    if (this.rich) {
      this.rich.dispose();
    }
  }
}
