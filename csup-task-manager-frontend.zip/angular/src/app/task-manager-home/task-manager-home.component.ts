import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-manager-home',
  templateUrl: './task-manager-home.component.html',
  styleUrls: ['./task-manager-home.component.sass']
})
export class TaskManagerHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
