import { APP_INITIALIZER, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { ClipboardModule } from '@angular/cdk/clipboard';
import { AgGridModule } from 'ag-grid-angular';

// material
import { MaterialModuleModule } from './material-module/material.module';
// material
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MomentDateModule } from '@angular/material-moment-adapter';
import { DragDropModule } from "@angular/cdk/drag-drop";
import { DatePipe } from '@angular/common';
// components
import { HeaderComponent } from './layout/header/header.component';
import { SideNavComponent } from './layout/side-nav/side-nav.component';
import { HeaderContentComponent } from './layout/header/header-content/header-content.component';
import { ConfigLoaderService } from './services/config-loader.service';

import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core'
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DecimalPipe } from '@angular/common';
import { AllowNumberDirective } from './directives/allow-number.directive';
import { ProgramComponent } from './program/program.component';
import { ProjectComponent } from './project/project.component';
import { TaskManagerHomeComponent } from './task-manager-home/task-manager-home.component';

const CUSTOM_DATE_FORMATS = {
  parse: {
    dateInput: 'DD MMMM YYYY',
  },
  display: {
    dateInput: 'DD MMMM YYYY',
    monthYearLabel: 'MMMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SideNavComponent,
    HeaderContentComponent,
    AllowNumberDirective,
    ProgramComponent,
    ProjectComponent,
    TaskManagerHomeComponent,
  ],   
  imports: [
    BrowserModule,
    AgGridModule.withComponents([]),
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    MaterialModuleModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MomentDateModule,
    DragDropModule,
    ClipboardModule
  ],
  providers: [{
    provide: APP_INITIALIZER, 
    useFactory: appInitializerFactory, 
    deps: [ConfigLoaderService],
    multi: true
  },
  {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
  { provide: MAT_DATE_FORMATS, useValue: CUSTOM_DATE_FORMATS },
  { provide: DecimalPipe},
  DatePipe
  
],
  bootstrap: [AppComponent]
})
export class AppModule { }

export function appInitializerFactory(configLoaderService: ConfigLoaderService) {
  return () => configLoaderService.loadConfig(); 
}
