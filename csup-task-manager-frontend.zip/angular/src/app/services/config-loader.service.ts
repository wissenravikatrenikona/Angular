import { Injectable } from '@angular/core';
import { HttpClient, HttpBackend } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class ConfigLoaderService {

   private httpClient: HttpClient;
   private config!: Config;

  constructor(handler: HttpBackend) {
    this.httpClient = new HttpClient(handler); 
  }

  get apiEndpoint() {
    return this.config.apiEndpoint; 
  }

  get configLoadedFrom() {
    return this.config.configLoadedFrom;
  } 

  get environment(){
    return this.config.environment;
  }

  public async loadConfig() : Promise<any> {
    let configPath = 'assets/config.json';
    /* TODO-START: REMOVE THIS LOGIC ONCE APP SERVICE MIGRATION IS DONE */
    let originUrl = new URL(window.location.href).origin;
    if(originUrl.indexOf('stcsupqa') != -1){
      configPath = 'assets/config-qa.json';
    }
    /* TODO-END */
    return this.httpClient.get(configPath).pipe(settings => settings)
      .toPromise()
      .then(settings => {
        this.config = settings as Config; 
      });
  }
}

export interface Config {
  apiEndpoint: string;
  configLoadedFrom: string;
  environment: string;
}