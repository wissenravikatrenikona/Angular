import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { ApiHttpService } from '../config/api-http.service';
import { ApiEndpointsService } from '../config/api-endpoints.service';
import { MatTableDataSource } from '@angular/material/table';

@Injectable({
  providedIn: 'root'
})
export class MdmService {
    
  countries: Map<string, string> = new Map<string, string>();
  searchResults!: MatTableDataSource<any>;

  constructor(private httpService: ApiHttpService, private urlService: ApiEndpointsService) { }

  getCountries(){
    return this.httpService.get(this.urlService.createUrl('countries'));
  }

  getMainLob(){
    return this.httpService.get(this.urlService.createUrl('mdm/mainLobList'));
  }

  getCarrier(){
    return this.httpService.get(this.urlService.createUrl('mdm/carrier/list'));
  }

  getTransactionType(){
    return this.httpService.get(this.urlService.createUrl('mdm/transactiontype/list'));
  }


  getSubLobList(){
    return this.httpService.get(this.urlService.createUrl('mdm/subLobList'));
  }

  getSubLobListByMainId(id:string){
    return this.httpService.get(this.urlService.createUrl('mdm/subLob/'+id));
  }

  getLOBHierarchy(){
    return this.httpService.get(this.urlService.createUrl('mdm/lobHierarchy'));
  }


  getCostingModel(){
    return this.httpService.get(this.urlService.createUrl('mdm/costingmodel/list'));
  }


  getCurrency(){
    return this.httpService.get(this.urlService.createUrl('mdm/currency/list'));
  }

  getProfitCenter(){
    return this.httpService.get(this.urlService.createUrl('mdm/profitcenter/org'));
  }

  getProductOrganization(){
    return this.httpService.get(this.urlService.createUrl('mdm/product/org'));
  }

  
  getCountryImgUrl(country: string) {
    //find countryCode
    let countryCode = this.countries.get(country);
    if(!countryCode){
      countryCode = country.toLowerCase();
    }
    return this.urlService.createUrl('countries/'+countryCode+'/flag');
  }

  cpSearch(payload: any){
    return this.httpService.post(this.urlService.createUrl('cp/results'), payload);
  }
}
