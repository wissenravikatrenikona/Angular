import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { ApiHttpService } from '../config/api-http.service';
import { ApiEndpointsService } from '../config/api-endpoints.service';
import { ConstantsService } from '../config/constants.service';

@Injectable({
  providedIn: 'root'
})
export class InvoiceService {

  constructor(private httpService: ApiHttpService, private urlService: ApiEndpointsService,
    private constants: ConstantsService) { }

  getInvoiceList(tranId: string){
    return this.httpService.get(this.urlService.createUrl(`/${tranId}/invoices`));
  }

  createInvoice(tranId: string, payload: any){
    return this.httpService.post(this.urlService.createUrl(`${tranId}/invoices`), payload);
  }

  updateInvoice(tranId: string, invoiceId: string, payload: any){
    return this.httpService.put(this.urlService.createUrl(`${tranId}/invoices/${invoiceId}`), payload);
  }

  deleteInvoice(transactionId: string, invoiceId: string){
    return this.httpService.delete(this.urlService.createUrl(`${transactionId}/invoices/${invoiceId}`));
  } 

  copyInvoice(tranId: string, invoiceId: string){
    return this.httpService.get(this.urlService.createUrl(`${tranId}/invoices/${invoiceId}/copy`));
  }
}
