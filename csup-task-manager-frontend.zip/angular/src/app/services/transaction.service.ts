import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { of } from 'rxjs';
import { ApiEndpointsService } from '../config/api-endpoints.service';
import { ApiHttpService } from '../config/api-http.service';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {

  readonly prefUrlPrefix = 'preference/';
  readonly transUrlPrefix = 'transaction/';

  constructor(private httpService: ApiHttpService, private urlService: ApiEndpointsService) { }

  getListOfPreferences(id:string){
    return this.httpService.get(this.urlService.createUrlWithPathVariables(this.prefUrlPrefix + 'list',[id]));
  }

  editFavorite(payload: any, id: any){
    return this.httpService.put(this.urlService.createUrlWithPathVariables(this.prefUrlPrefix + 'edit', [id]), payload);
  }

  saveFavorite(payload: any){
    return this.httpService.post(this.urlService.createUrl(this.prefUrlPrefix + 'save'), payload);
  }

  deletePreferences(id: string){
    return this.httpService.delete(this.urlService.createUrlWithPathVariables(this.prefUrlPrefix + 'delete',[id]));
  }

  getSelectedPreferences(id: string){
    return this.httpService.get(this.urlService.createUrlWithPathVariables(this.prefUrlPrefix + 'populate',[id]));
  }

  getAdditionalFields(){
    return this.httpService.get(this.urlService.createUrl(this.prefUrlPrefix + 'additional/fields'));
  }

  getTransactionInitialFields(){
    return this.httpService.get(this.urlService.createUrl(this.transUrlPrefix + 'fields'));
  }

  transactionSearch(payload: any){
    return this.httpService.post(this.urlService.createUrl(this.transUrlPrefix + 'search'), payload);
  }

  getPayload(transactionSearchForm: FormGroup){
    let transPayload = {};
    let fields = Object.keys(transactionSearchForm.controls);
    fields.map((field: string) => {
      let value = transactionSearchForm.get(field)?.value;
      if(value)
        Object.assign(transPayload,{[field]: value});
    });
    return transPayload;
  }

  getFavoritePayload(transactionSearchForm: FormGroup, favPayload: any, additionalFields: any[]){
    let fieldKeys = Object.keys(transactionSearchForm.controls);
    let addnFieldKeys: any = [];
    additionalFields.map(field => addnFieldKeys.push(field.fieldKey));
    fieldKeys.map(key => {
      if(addnFieldKeys.indexOf(key) != -1 || transactionSearchForm.get(key)?.dirty){
        this.setFavoritePayload(key, favPayload, transactionSearchForm.get(key)?.value);
      }
    });
    return favPayload;
  }

  setFavoritePayload(key: string, favPayload: any, value: any){
    if(value instanceof moment){
      let dateValue = moment(value);
      value = dateValue?.utc().format();
    }
    favPayload.userPreferencesMgmtDto.userPreferencesDataDto.push({
        prefKey: key,
        prefOrderPosition: "",
        prefValue: value ? value.toString() : ""
    });
  }

  setSearchCriteria(userPrefs: any, transactionSearchForm: FormGroup, customizeFieldsList: any, additionalFields: any[]){    
    userPrefs.map((pref: any) => {
      let field = pref['prefKey'];
      if(pref['prefValue'].split(",").length > 1){
        pref['prefValue'] = pref['prefValue'].split(",");
      }
      transactionSearchForm.patchValue({[field]: pref['prefValue']});
      
      let customFieldObj = customizeFieldsList.get(field);
      if(customFieldObj) additionalFields.push(customFieldObj);
    });    
  }
  
  flatten(obj: any){
    let res: any = {};
    for (const [key, value] of Object.entries(obj)) {
        if (typeof value === 'object') {
            res = { ...res, ...this.flatten(value) };
        } else {
            res[key] = value;
        }
    }
    return res;
  }
  
  getTransactionById(id: string) {
    return this.httpService.get(this.urlService.createUrl(`transactions/${id}`, false));
  }
}
