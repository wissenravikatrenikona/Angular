import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { ApiHttpService } from '../config/api-http.service';
import { ApiEndpointsService } from '../config/api-endpoints.service';

@Injectable({
  providedIn: 'root'
})
export class ClientService {
  
  constructor(private httpService: ApiHttpService, private urlService: ApiEndpointsService) { }
  
  findClientById(clientId: string){
    return this.httpService.get(this.urlService.createUrl(`clients/${clientId}`));
  }

  
}
