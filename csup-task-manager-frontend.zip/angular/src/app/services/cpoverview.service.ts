import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class CpoverviewService {
  data: any;
  constructor(private http: HttpClient) {

  }
  getCPdetails(id:any): Observable<any> {
    this.data = this.http.get('https://app-csup-frp-proxy-service.azurewebsites.net/frp/getCounterPartyDetails?cpId='+id);
    return this.data;
  }
}
