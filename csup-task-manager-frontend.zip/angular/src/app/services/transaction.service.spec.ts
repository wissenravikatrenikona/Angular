import { TestBed } from '@angular/core/testing';

import { TransactionService } from './transaction.service';
import {HttpClientModule} from '@angular/common/http';
import { Form, FormBuilder, FormGroup } from '@angular/forms';
import { UserPreferences } from '../model/user-preferences';
import userPreferences from '../model/data/user-preferences.json';

describe('TransactionService', () => {
  let service: TransactionService;
  const rootUrl = 'http://localhost:8080//';
  const id = '1';
  const formBuilder: FormBuilder = new FormBuilder();
  const tranSearchForm: FormGroup = formBuilder.group({
    transId: [null],
    accountId: [''],
    cpName: [null],
    cpCountry: ['CODE0'],
    cpRating: [null]
  });

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      providers: [TransactionService, { provide: FormBuilder, useValue: formBuilder }]});
    service = TestBed.inject(TransactionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  
  it('should getListOfPreferences', () => {
    const spyObj = jest.spyOn(service['httpService'], 'get');
    service.getListOfPreferences(id);
    expect(spyObj).toHaveBeenCalled();    
    expect(spyObj).toHaveBeenCalledWith(rootUrl + service.prefUrlPrefix + 'list/'  + id);
  });

  it('should editFavorite', () => {
    const spyObj = jest.spyOn(service['httpService'], 'put');
    service.editFavorite({}, id);
    expect(spyObj).toHaveBeenCalled();    
    expect(spyObj).toHaveBeenCalledWith(rootUrl + service.prefUrlPrefix + 'edit/' + id, {});
  });

  it('should saveFavorite', () => {
    const spyObj = jest.spyOn(service['httpService'], 'post');
    service.saveFavorite({});
    expect(spyObj).toHaveBeenCalled();    
    expect(spyObj).toHaveBeenCalledWith(rootUrl + service.prefUrlPrefix + 'save', {});
  });

  it('should deletePreferences', () => {
    const spyObj = jest.spyOn(service['httpService'], 'delete');
    service.deletePreferences(id);
    expect(spyObj).toHaveBeenCalled();    
    expect(spyObj).toHaveBeenCalledWith(rootUrl + service.prefUrlPrefix + 'delete/' + id);
  });

   it('should getSelectedPreferences', () => {
    const spyObj = jest.spyOn(service['httpService'], 'get');
    service.getSelectedPreferences(id);
    expect(spyObj).toHaveBeenCalled();    
    expect(spyObj).toHaveBeenCalledWith(rootUrl + service.prefUrlPrefix + 'populate/' + id);
  });
  
  it('should getAdditionalFields', () => {
    const spyObj = jest.spyOn(service['httpService'], 'get');
    service.getAdditionalFields();
    expect(spyObj).toHaveBeenCalled();    
    expect(spyObj).toHaveBeenCalledWith(rootUrl + service.prefUrlPrefix + 'additional/fields');
  });

  it('should getTransactionInitialFields', () => {
    const spyObj = jest.spyOn(service['httpService'], 'get');
    service.getTransactionInitialFields();
    expect(spyObj).toHaveBeenCalled();    
    expect(spyObj).toHaveBeenCalledWith(rootUrl + service.transUrlPrefix + 'fields');
  });
  
  it('should transactionSearch', () => {
    const spyObj = jest.spyOn(service['httpService'], 'post');
    service.transactionSearch({});
    expect(spyObj).toHaveBeenCalled();    
    expect(spyObj).toHaveBeenCalledWith(rootUrl + service.transUrlPrefix + 'search', {});
  });

  it('should flatten the object', () => {
    let obj = {'test':'one', 'nested': {'inner': 'two'}};
    let result = service.flatten(obj);
    expect(result['inner']).toBe('two');
  });

  it('should getPayload', () => {
    let payload: any = service.getPayload(tranSearchForm);
    expect(payload['cpCountry']).toBe('CODE0');
  });

  it('should getFavoritePayload', () => {
    tranSearchForm.get('cpCountry')?.markAsDirty();
    let favPayload: UserPreferences = userPreferences;
    favPayload = service.getFavoritePayload(tranSearchForm, favPayload, []);
    expect(favPayload.userPreferencesMgmtDto.userPreferencesDataDto.length).toBeGreaterThan(0);
  });

  it('should setSearchCriteria', () => {
    let userPrefs = [{"prefKey": "cpCountry", "prefValue": "Swiss"}];
    let customFields = new Map();
    service.setSearchCriteria(userPrefs, tranSearchForm, customFields, []);
    expect(tranSearchForm.get('cpCountry')?.value).toBe("Swiss");
  });
});