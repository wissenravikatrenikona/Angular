import { HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';

import { InitialCostingService } from './initial-costing.service';

describe('InitialCostingService', () => {
  let service: InitialCostingService;
  const rootUrl = 'http://localhost:8080//';
  const id = '1005949';
  beforeEach(() => {
    TestBed.configureTestingModule({imports: [HttpClientModule],
      providers: [InitialCostingService, { provide: FormBuilder }]});
    service = TestBed.inject(InitialCostingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should getProductPopUpInitialFields', () => {
    const spyObj = jest.spyOn(service['httpService'], 'get');
    service.getProductPopUpInitialFields(id);
    expect(spyObj).toHaveBeenCalled();    
    expect(spyObj).toHaveBeenCalledWith(rootUrl + service.prefUrlPrefix + 'list/'  + id);
  });

  it('should getProductCategoryPopUpInitialFields', () => {
    const spyObj = jest.spyOn(service['httpService'], 'get');
    service.getProductCategoryPopUpInitialFields(id);
    expect(spyObj).toHaveBeenCalled();    
    expect(spyObj).toHaveBeenCalledWith(rootUrl + service.prefUrlPrefix + 'category/'  + id);
  });


});
