import { HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';

import { CpoverviewService } from './cpoverview.service';

describe('CpoverviewService', () => {
  let service: CpoverviewService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      providers: [CpoverviewService]
    });
    service = TestBed.inject(CpoverviewService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
