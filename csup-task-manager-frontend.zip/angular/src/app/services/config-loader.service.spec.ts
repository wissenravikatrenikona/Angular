import { TestBed } from '@angular/core/testing';

import { ConfigLoaderService } from './config-loader.service';
import {HttpClientModule} from '@angular/common/http';

describe('ConfigLoaderService', () => {
  let service: ConfigLoaderService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      providers: [ConfigLoaderService]
  });
    service = TestBed.inject(ConfigLoaderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
