import { TestBed } from '@angular/core/testing';

import { MdmService } from './mdm.service';
import {HttpClientModule} from '@angular/common/http';

describe('MdmService', () => {
  let service: MdmService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      providers: [MdmService]
    });
    service = TestBed.inject(MdmService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
