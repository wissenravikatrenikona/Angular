import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HeaderService {

  environment: string = 'Development';

  getEnvironment(){
    return this.environment;
  }
}
