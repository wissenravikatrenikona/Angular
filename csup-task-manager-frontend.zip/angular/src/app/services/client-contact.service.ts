import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { ApiHttpService } from '../config/api-http.service';
import { ApiEndpointsService } from '../config/api-endpoints.service';
import { ConstantsService } from '../config/constants.service';

@Injectable({
  providedIn: 'root'
})
export class ClientContactService {
  
  constructor(private httpService: ApiHttpService, private urlService: ApiEndpointsService,
    private constants: ConstantsService) { }

  findAllContats(clientId: string){
    let url1 = this.constants.API_ENDPOINT + "/partners/"+clientId+"/contacts";
    console.log(url1)
    return this.httpService.get(url1);
  }

  findContatById(clientId: string, contactId: string){
    let contactUrl=this.constants.API_ENDPOINT + "/partners/"+clientId +"/contacts/"+contactId;
    return this.httpService.get(contactUrl);
  }

  deleteContatById(clientId: string, contactId: string){
    let contactUrl=this.constants.API_ENDPOINT + "/partners/"+clientId +"/contacts/"+contactId;
    return this.httpService.delete(contactUrl);
  }

  createContact(clientId: string, payload: any){
    let contactUrl=this.constants.API_ENDPOINT + "/partners/"+clientId +"/contacts";
    return this.httpService.post(contactUrl, payload);
  }

  updateContact(clientId: string, contactId: string, payload: any){
    let contactUrl=this.constants.API_ENDPOINT + "/partners/"+clientId +"/contacts/"+ contactId;    
    return this.httpService.put(contactUrl, payload);
  }

}
