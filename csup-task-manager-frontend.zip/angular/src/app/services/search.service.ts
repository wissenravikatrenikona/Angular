import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { ApiHttpService } from '../config/api-http.service';
import { ApiEndpointsService } from '../config/api-endpoints.service';
import { MatTableDataSource } from '@angular/material/table';

@Injectable({
  providedIn: 'root'
})
export class SearchService {
    
  countries: Map<string, string> = new Map<string, string>();
  searchResults!: MatTableDataSource<any>;

  constructor(private httpService: ApiHttpService, private urlService: ApiEndpointsService) { }

  getCountries(){
    return this.httpService.get(this.urlService.createUrl('countries'));
  }

  getIndustry(){
    return this.httpService.get(this.urlService.createUrl('industries'));
  }

  getCountryImgUrl(country: string) {
    //find countryCode
    let countryCode = this.countries.get(country);
    if(!countryCode){
      countryCode = country.toLowerCase();
    }
    return this.urlService.createUrl('countries/'+countryCode+'/flag');
  }

  cpSearch(payload: any){
    return this.httpService.post(this.urlService.createUrl('cp/results'), payload);
  }
}
