import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { ApiEndpointsService } from '../config/api-endpoints.service';
import { ApiHttpService } from '../config/api-http.service';
import { QueryStringParameters } from 'src/app/config/query-string-parameters';
import { SaveRequest } from '../initial-costing/initial-costing-model';

@Injectable({
  providedIn: 'root'
})
export class InitialCostingService {

  readonly initCostUrlPrefix = 'initial/costing/';
  readonly productPrefix = this.initCostUrlPrefix + 'product/';
  readonly genericPrefix = this.initCostUrlPrefix + 'generic/';
  readonly riskType = this.initCostUrlPrefix + 'risk/';
  readonly underwriter = this.initCostUrlPrefix + 'underwriters';
  readonly rdsProductPricing = 'rds/product/pricing/parameters';
  readonly rdsscenariolist = 'rds/scenario/list';
  readonly rdsrsq = 'rds/rsq';
  readonly rdsipd = 'rds/ipd';
  readonly cpDetail = 'cp';
  readonly ratingList = 'mdm/rating/list';
  readonly ratingBasedPD = 'rds/ratingbasedpd';
  readonly saveCalculateUrl = this.initCostUrlPrefix + 'calculate/save/';
  
  
  coverUpdated = new BehaviorSubject<Boolean>(false);

  readonly daycount = this.initCostUrlPrefix + 'daycount';
  /* GENERIC COSTING MODEL */
  productSelected = new BehaviorSubject<Boolean>(false);
  exposureStartDate: any;
  exposureMaturity: any;
  validFromDate:any;
  validToDate:any;
  coverValue: any;
  messageSource: BehaviorSubject<string> = new BehaviorSubject('');

  private rdsFieldResData = new BehaviorSubject<any>(null);
  public rdsFieldResData$ = this.rdsFieldResData.asObservable();

  subLOBDat: BehaviorSubject<any> = new BehaviorSubject([]);
  constructor(private httpService: ApiHttpService, private urlService: ApiEndpointsService) { }
  
  setRdsData(data: any){
    this.rdsFieldResData.next(data);
  }
  getRdsPricingInitialFields(obj:any){
    return this.httpService.get(this.urlService.createUrlWithQueryParameters(this.rdsProductPricing, (qs: QueryStringParameters) => {
      qs.push('loBId', obj.lobId);
      qs.push('productID', obj.productId);
      qs.push('referenceDateForPD', obj.refdatepd);
      qs.push('referenceDate', obj.refdate);
      qs.push('inceptionDate', obj.iceDate);
  }));
  }
  getProductPopUpInitialFields(id: string) {
    return this.httpService.get(this.urlService.createUrlWithPathVariables(this.productPrefix + 'list', [id]));
  }

  getProductCategoryPopUpInitialFields(id: string) {
    return this.httpService.get(this.urlService.createUrlWithPathVariables(this.productPrefix + 'category', [id]));
  }

  getAddedProductData() {
    return this.httpService.get(this.urlService.createUrl(this.productPrefix + 'data'));
  }

  getGenericFields() {
    return this.httpService.get(this.urlService.createUrl(this.genericPrefix + 'fields'));
  }

  getRiskTypedata() {
    return this.httpService.get(this.urlService.createUrl(this.riskType + 'type'));
  }

  getUnderwriters() {
    return this.httpService.get(this.urlService.createUrl(this.underwriter));
  }
  getDayCount() {
    return this.httpService.get(this.urlService.createUrl(this.daycount));
  }
  getCountries(){
    return this.httpService.get(this.urlService.createUrl('countries'));
  }
  getRatings(){
    return this.httpService.get(this.urlService.createUrl(this.ratingList));
  }

  getCpDetail(cpId:any) {
    return this.httpService.get(this.urlService.createUrlWithQueryParameters(this.cpDetail, (qs: QueryStringParameters) => {
      qs.push('counterPartyId', cpId);
  }));
  }

  getRsqValue(cpId:any,referenceDate: any,referenceDateForPD: any){
    return this.httpService.get(this.urlService.createUrlWithQueryParameters(this.rdsrsq, (qs: QueryStringParameters) => {
      qs.push('counterPartyId', cpId);
      qs.push('referenceDate', referenceDate);
      qs.push('referenceDateForPD', referenceDateForPD);
  }));

  }


  
  getRatingBasedPD(rating:any,cpId:any,referenceDate: any,referenceDateForPD: any){
    return this.httpService.get(this.urlService.createUrlWithQueryParameters(this.ratingBasedPD, (qs: QueryStringParameters) => {
      qs.push('rating', rating);
      qs.push('counterPartyId', cpId);
      qs.push('referenceDate', referenceDate);
      qs.push('referenceDateForPD', referenceDateForPD);
  }));
  }


  getIpd(cpId:any,referenceDate: any,referenceDateForPD: any){
    return this.httpService.get(this.urlService.createUrlWithQueryParameters(this.rdsipd, (qs: QueryStringParameters) => {
      qs.push('counterPartyId', cpId);
      qs.push('referenceDate', referenceDate);
      qs.push('referenceDateForPD', referenceDateForPD);
  }));
  }
  getScenarios(referenceDate: any,referenceDateForPD: any){
    return this.httpService.get(this.urlService.createUrlWithQueryParameters(this.rdsscenariolist, (qs: QueryStringParameters) => {
      qs.push('referenceDate', referenceDate);
      qs.push('referenceDateForPD', referenceDateForPD);
  }));
  }

  saveAndCalculate(saveRequest: SaveRequest) {
    let url = this.urlService.createUrl(this.saveCalculateUrl);
    return this.httpService.post(url, saveRequest);
  }

}
//https://app-backend-for-frontend-service.azurewebsites.net/rds/product/pricing/parameters?loBId=1005949&productID=2001205&referenceDateForPD=2021-08-01&referenceDate=2021-08-01&inceptionDate=2021-08-01