import { TestBed } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { AppTestingModule } from './app-testing/app-testing.module';
import { ConstantsService } from './config/constants.service';
import { of } from 'rxjs';
import { ConfigLoaderService } from './services/config-loader.service';
import { Component } from '@angular/core';

class MockConfigService {
  get apiEndpoint() {
    return "localhost"; 
  }
  get environment(){
    return "test";
  }
}

@Component({selector: 'app-header', template: ''})
 class HeaderComponent {}
 
describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AppTestingModule ],
      declarations: [
        AppComponent,
        HeaderComponent
      ],
      providers: [
        {provide: ConfigLoaderService, useClass: MockConfigService}
       ]
    }).compileComponents(); 
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });
});
