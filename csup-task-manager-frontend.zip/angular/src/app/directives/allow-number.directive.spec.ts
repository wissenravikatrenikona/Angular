import { AllowNumberDirective } from './allow-number.directive';

describe('AllowNumberDirective', () => {
  it('should create an instance', () => {
    const directive = new AllowNumberDirective();
    expect(directive).toBeTruthy();
  });
});
