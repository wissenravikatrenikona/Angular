export class TransactionMainInformation {
  txName: string =''
  inquiryDate: string = ''
  txDescription: string =''
  mainLob:string =''
  transactionType:string =''
  sublob:string =''
  transactionIndustry:string=''
  profitcenter:string =''
  riskType: string = ''
  productorg:string = ''
  transactionChannel: string = ''
  clientReference: string=''
}