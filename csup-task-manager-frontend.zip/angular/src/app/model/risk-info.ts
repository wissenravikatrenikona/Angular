export class RiskInfo{
    rsq: number 
  }

