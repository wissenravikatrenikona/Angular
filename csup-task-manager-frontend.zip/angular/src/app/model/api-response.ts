export interface ApiResponse {
    collection: boolean;
    data: any[];
    status: string;
    timestamp: any;
}