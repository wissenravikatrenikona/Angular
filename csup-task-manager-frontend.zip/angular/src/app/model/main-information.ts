export class MainInformation {
  cpdetail: string = ''
  mainLob:string =''
  carrier:string =''
  transactionType:string =''
  sublob:string =''
  profitcenter:string =''
  productorg:string = ''
  costingMode:string =''
  counterparty:string = ''
  underwriter: string = ''
  riskType: string = ''
}