export class ProductCard{
  validFromDate = new Date()
  validToDate = new Date(new Date().setFullYear(new Date().getFullYear() + 1))
  expoExpirationDate = new Date(new Date().setFullYear(new Date().getFullYear() + 1,new Date().getMonth(),new Date().getDay()+60))
  coverPersentField='0.00'
  srShareField='100.00'
  srCoverField='0.00'
  commissionField='0.00'
  brokerageField='0.00'
  otherExpensesField='0.00'
  diffFromToField=365
  diffToExpoField=60
  courrency='EUR'
  courrencyList:any[] = []
  onNetBrokerage:any=''
  onNetCommission:any=''
  onNetCommCheckBox = false
  onNetBrCheckBox = false
  
  }