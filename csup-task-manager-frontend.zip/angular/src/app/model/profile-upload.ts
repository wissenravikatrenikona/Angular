export class ProfileUpload{
    measurementVal: string = '50'
    copiedExcelList: string = ''
  }


