export interface UserPreferences {
    createdTime?: string,
    modifiedTime? : string,
    firstName: string,
    lastName: string,
    userId: number,
    userName: string,
    userPreferencesMgmtDto: {
      prefId: number,
      preferenceName: string,
      preferenceStatus: string,
      preferenceType: string,
      userPreferencesDataDto: any,
      userid: number
    },
    userRole: string,
    userStatus: string
  }