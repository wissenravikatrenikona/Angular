import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ConstantsService {

  public API_ENDPOINT: string = 'http://localhost:8080/';
  
  public API_MOCK_ENDPOINT: string = 'https://app-csup-invoice-service.azurewebsites.net/';

}
